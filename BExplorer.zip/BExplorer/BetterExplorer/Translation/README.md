# BetterExplorer Translations

To work on translations for BetterExplorer, send me an email at jacobrh94@hotmail.com or fork the repository at http://github.com/JaykeBird/BE_Translations